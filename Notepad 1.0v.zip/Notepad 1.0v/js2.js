const textarea = document.getElementById("note3");

// Load saved note on popup open
chrome.storage.local.get(["note3"], (result) => {
  if (result.note3) {
    textarea.value = result.note3;
  }
});

// Save note every time user types
textarea.addEventListener("input", () => {
  chrome.storage.local.set({ note3: textarea.value });
});
