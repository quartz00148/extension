const textarea = document.getElementById("note2");

// Load saved note on popup open
chrome.storage.local.get(["note2"], (result) => {
  if (result.note2) {
    textarea.value = result.note2;
  }
});

// Save note every time user types
textarea.addEventListener("input", () => {
  chrome.storage.local.set({ note2: textarea.value });
});
