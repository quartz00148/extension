const textarea = document.getElementById("note1");

// Load saved note on popup open
chrome.storage.local.get(["note1"], (result) => {
  if (result.note1) {
    textarea.value = result.note1;
  }
});

// Save note every time user types
textarea.addEventListener("input", () => {
  chrome.storage.local.set({ note1: textarea.value });
});
